#Functonality part
from re import search
from tkinter import *
from tkinter import ttk

def employee_form():
    global back_image
    employee_frame=Frame(window,width=1070,height=567)
    employee_frame.place(x=200,y=100)
    heading_Label=Label(employee_frame,text='Manage Employee Details',font=('times new roman',16,'bold'),bg='#0f4d7d',fg='white')
    heading_Label.place(x=0,y=0,relwidth=1)

    back_image=PhotoImage(file="back_button.pmg")
    back_button=Button(employee_frame,image=back_image,bd=0,cursor='hand2',command=lambda: emplyooe_frame.place_forget())
    back_button.place(x=10,y=30)
    top_frame=Frame(employee_frame)
    top_frame.place(x=0,y=60,relwidth=1,heigth=235)
    search_frame=Frame(top_frame)
    search_frame.pack()

    search_combobox=ttk.combobox(search_frame,values=('Id','Name','Email'),font=('times new roman',12),state='readonly')
    search_combobox.set('search By')
    search_combobox.grid(row=0,column=0,padx=20)
    serach_entry=Entry(search_frame,font('times new roman',12),bg='lightyellow')
    search_entry.grid(row=0,column=1)
    search_button=Button(search_frame,text='Search',font=('times new roman',12),width=10,cursor='hand2',fg='white',bg='#0f4d7d')
    search_button.grid(row=0,column=2,padx=20)
    show_button=Button(search_frame,text='Show All',font=('times new roman',12),width=10,cursor='hand2',fg='white',bg='#0f4d7d')
    show_button.grid(row=0,column=3,padx=20)

    horizontalscrollbar=Scrollbar(top_frame,orient=HORIZONTAL)
    vertical_scrollbar=Scrollbar(top_frame,orient=VERTICAL)
    employee_trewview=ttk.Treeview(top_frame,columns=('empid','name','email','gender','dob','contact','employment_type'
                                                        'education','work_shift','adress','doj','salary','usertype'),show='headings',
                                   yscrollcommand=vertical_scrollbar.set,xscrollcommand=horizontal_scrollbar.set)

    employee_treeview.pack(pady=10)
    employee_treeview.heading('empid',text='Empid')
    employee_treeview.heading('name',text='Name')
    employee_treeview.heading('email',text='Email')
    employee_treeview.heading('gender',text='Gender')
    employee_treeview.heading('dob',text='Date of Birth')
    employee_treeview.heading('contact',text='Contact')
    employee_treeview.heading('employee_type',text='Employment Type')
    employee_treeview.heading('education',text='Education')
    employee_treeview.heading('work_shift',text='Work Shift')
    employee_treeview.heading('adress',text='Adress')
    employee_treeview.heading('doj',text='Date of Joining')
    employee_treeview.heading('salary',text='Salary')
    employee_treeview.heading('usertype',text='User Type')

    employee_treeview.column('empid', width=60)
    employee_treeview.column('name', width=140)
    employee_treeview.column('email', width=180)
    employee_treeview.column('gender', width=80)
    employee_treeview.column('dob', width=100)
    employee_treeview.column('contact', width=80)
    employee_treeview.column('employee_type', width=120)
    employee_treeview.column('education', width=120)
    employee_treeview.column('work_shift', width=120)
    employee_treeview.column('adress', width=200)
    employee_treeview.column('doj', width=100)
    employee_treeview.column('salary', width=140)
    employee_treeview.column('usertype', width=120)

